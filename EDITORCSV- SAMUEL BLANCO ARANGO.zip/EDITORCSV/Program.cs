﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EDITORCSV
{
    class Program
    {
        static void Main(string[] args)
        {
            EDITORCSV("Cristiano", "Ronaldo", "dos Santos Aveiro.", "Portugal");
        }
        static void EDITORCSV(string Nombre, string Apellido, string Pais, string v)
        {
            string ruta = @"C:\Users\samue\VISUAL ESTUDIO\EDITORCSV\Usuarios.csv";
            string separador = ",";
            StringBuilder salida = new StringBuilder();

            string cadena = Nombre + "," +Apellido + "," + Pais;   
            List <string> lista = new List<string>();
            lista.Add(cadena);

            for (int i = 0; i < lista.Count; i++) 
            {
                salida.AppendLine(string.Join(separador, lista[i]));
                File.AppendAllText(ruta, salida.ToString());
            }
                }

        }
    }

