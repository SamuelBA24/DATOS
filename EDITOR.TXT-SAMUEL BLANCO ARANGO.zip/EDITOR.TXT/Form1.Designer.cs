﻿namespace EDITOR.TXT
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnEscribir = new System.Windows.Forms.Button();
            this.BtnLeer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnEscribir
            // 
            this.BtnEscribir.Location = new System.Drawing.Point(95, 34);
            this.BtnEscribir.Name = "BtnEscribir";
            this.BtnEscribir.Size = new System.Drawing.Size(107, 40);
            this.BtnEscribir.TabIndex = 0;
            this.BtnEscribir.Text = "ESCRIBIR";
            this.BtnEscribir.UseVisualStyleBackColor = true;
            this.BtnEscribir.Click += new System.EventHandler(this.BtnEscribir_Click);
            // 
            // BtnLeer
            // 
            this.BtnLeer.Location = new System.Drawing.Point(95, 106);
            this.BtnLeer.Name = "BtnLeer";
            this.BtnLeer.Size = new System.Drawing.Size(107, 43);
            this.BtnLeer.TabIndex = 1;
            this.BtnLeer.Text = "LEER";
            this.BtnLeer.UseVisualStyleBackColor = true;
            this.BtnLeer.Click += new System.EventHandler(this.BtnLeer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(305, 273);
            this.Controls.Add(this.BtnLeer);
            this.Controls.Add(this.BtnEscribir);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnEscribir;
        private System.Windows.Forms.Button BtnLeer;
    }
}

