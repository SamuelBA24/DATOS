﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;// LIBERÍA PARA TRABAJAR CON ESTE TIPO DE ARCHIVOS
namespace EDITOR.TXT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnEscribir_Click(object sender, EventArgs e)
        {
            TextWriter Escribir = new StreamWriter("TextPrueba.Txt");// Se crea un primer objeto de tipo txtWriter en este se combiana las clases
            Escribir.WriteLine("Si la vida fuera estable todo el tiempo\r\nYo no bebería ni malgastaría la plata\r\nSi la vida fuera estable todo el tiempo\r\nYo no bebería ni malgastaría la plata.RHLM BRRRRRRRRRRR");
            Escribir.Close();// Esto nos permite comunicarnos con el programa y el archivo y logicamente Abrir y cerrar este.Aparte de esto no le estamos dando ninguna otra instrucción
            MessageBox.Show("Listo");
            // AGREGAR LINEA DE TEXTO

            StreamWriter Agregarlinea = File.AppendText("TextPrueba.Txt");
            Agregarlinea.WriteLine("Se agrego una nueva linea...SIUUUUUUUUUUUUUUUUUUU");
            Agregarlinea.Close();


        }

        private void BtnLeer_Click(object sender, EventArgs e)
        {
            TextReader leer = new StreamReader("TextPrueba.Txt");
            //MessageBox.Show(leer.ReadLine());
            MessageBox.Show(leer.ReadToEnd () );


            leer.Close();
        
        
        
        
        
        }
    }
}
