﻿using System;
using System.Xml;

namespace EDITORXML
{
    class program
    {
        static void Main(String[] args)
        {
            XmlWriter EDITORXML = XmlWriter.Create("XMLARCHIVO");
            EDITORXML.WriteStartDocument();
            EDITORXML.WriteStartElement("Equipos");
            EDITORXML.WriteStartElement("Equipo");
            EDITORXML.WriteAttributeString("Tecnico", "Carlo anchelotti");
            EDITORXML.WriteStartElement("Nombre");
            EDITORXML.WriteString("Real Madrid");
            EDITORXML.WriteEndElement();
            EDITORXML.WriteString("24 Jugador");
            EDITORXML.WriteEndElement();






            EDITORXML.WriteEndElement();
            EDITORXML.Close();


        }
    }
}